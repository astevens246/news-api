class News < ApplicationRecord
end
